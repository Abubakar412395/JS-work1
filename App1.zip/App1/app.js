let startTime, updatedTime, difference, t;
let running = false;

function startTimer() {
    if (!running) {
        startTime = new Date().getTime() - (difference || 0);
        t = setInterval(updateTime, 10);
        running = true;
    }
}

function stopTimer() {
    clearInterval(t);
    running = false;
}

function resetTimer() {
    clearInterval(t);
    running = false;
    difference = 0;
    document.getElementById("minutes").innerHTML = "00";
    document.getElementById("seconds").innerHTML = "00";
    document.getElementById("milliseconds").innerHTML = "00";
}

function updateTime() {
    updatedTime = new Date().getTime();
    difference = updatedTime - startTime;

    let minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((difference % (1000 * 60)) / 1000);
    let milliseconds = Math.floor((difference % 1000) / 10);

    document.getElementById("minutes").innerHTML = (minutes < 10 ? "0" : "") + minutes;
    document.getElementById("seconds").innerHTML = (seconds < 10 ? "0" : "") + seconds;
    document.getElementById("milliseconds").innerHTML = (milliseconds < 10 ? "0" : "") + milliseconds;
}

document.getElementById("startBtn").onclick = startTimer;
document.getElementById("stopBtn").onclick = stopTimer;
document.getElementById("resetBtn").onclick = resetTimer;
